/* This file is auto generated, version 201607271333 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201607271333 SMP Wed Jul 27 17:36:45 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1) "
